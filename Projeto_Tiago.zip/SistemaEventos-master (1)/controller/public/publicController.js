async function home(req,res){
    res.render('public/index')
}

async function sobre(req,res){
    
}

async function ministrantes(req,res){
    
}

async function cronograma(req,res){
    
}

async function noticias(req,res){
    
}

async function contatos(req,res){
    
}

module.exports = {home,sobre,ministrantes,cronograma,noticias,contatos}